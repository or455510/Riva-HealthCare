<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medication extends Model
{
    protected $fillable = [
        'patient_id', 'name', 'dosage', 'schedule_time', 'frequency', 'instructions', 'is_active',
    ];

    protected $casts = ['is_active' => 'boolean'];

    public function patient() { return $this->belongsTo(Patient::class); }
    public function logs() { return $this->hasMany(MedicationLog::class); }
}
