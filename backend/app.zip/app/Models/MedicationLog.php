<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicationLog extends Model
{
    protected $fillable = [
        'medication_id', 'patient_id', 'scheduled_at', 'taken_at', 'status', 'confirmed_by',
    ];

    protected $casts = [
        'scheduled_at' => 'datetime',
        'taken_at' => 'datetime',
    ];

    public function medication() { return $this->belongsTo(Medication::class); }
    public function patient() { return $this->belongsTo(Patient::class); }
    public function confirmer() { return $this->belongsTo(User::class, 'confirmed_by'); }
}
