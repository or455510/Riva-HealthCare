<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

class NotificationService
{
    public function create(
        User $user,
        string $type,
        string $title,
        string $message,
        ?array $data = null,
        ?string $actionUrl = null,
        ?string $category = null
    ): Notification {
        return Notification::create([
            'notifiable_type' => User::class,
            'notifiable_id' => $user->id,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'data' => $data,
            'action_url' => $actionUrl,
            'category' => $category ?? $this->categorizeType($type),
        ]);
    }

    public function notify(
        User $user,
        string $type,
        string $title,
        string $message,
        ?array $data = null,
        ?string $actionUrl = null,
        bool $sendEmail = false
    ): Notification {
        $notification = $this->create($user, $type, $title, $message, $data, $actionUrl);

        if ($sendEmail) {
            $this->sendEmail($user, $title, $message, $actionUrl);
        }

        return $notification;
    }

    public function getUserNotifications(User $user, int $limit = 20)
    {
        return $user->notifications()
            ->latest()
            ->paginate($limit);
    }

    public function markAllAsRead(User $user): void
    {
        $user->notifications()
            ->whereNull('read_at')
            ->update(['read_at' => now()]);
    }

    private function categorizeType(string $type): string
    {
        return match ($type) {
            'follow_request_accepted', 'new_follow_request' => 'follows',
            'new_appointment', 'appointment_reminder', 'appointment_cancelled' => 'appointments',
            'medication_reminder', 'medication_missed' => 'medications',
            'daily_report_reminder', 'daily_status_risk', 'patient_risk_alert' => 'alerts',
            'doctor_comment' => 'comments',
            'new_review' => 'reviews',
            'password_reset', 'account_verification', 'password_changed' => 'account',
            'security_alert', 'login_alert' => 'security',
            'welcome' => 'system',
            default => 'general',
        };
    }

    private function sendEmail(User $user, string $title, string $message, ?string $actionUrl = null): void
    {
        Mail::raw(
            $message . ($actionUrl ? "\n\nOpen: {$actionUrl}" : ''),
            fn ($mail) => $mail->to($user->email)->subject($title)
        );
    }
}
