<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\DailyStatus;
use App\Models\Diagnosis;
use App\Models\Doctor;
use App\Models\LoginAttempt;
use App\Models\MedicationLog;
use App\Models\PatientDoctorRelationship;
use App\Models\Report;
use App\Models\SystemActivityLog;
use App\Models\User;
use App\Models\UserNotification;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function patient(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 403);

        $activeDoctor = PatientDoctorRelationship::with('doctor.user')
            ->where('patient_id', $patient->id)
            ->where('status', 'active')
            ->latest()
            ->first();

        $activeCaregiver = $patient->caregiverRelationships()->with('caregiver.user')->where('status', 'active')->latest()->first();
        $notifications = UserNotification::where('user_id', $request->user()->id)->latest()->take(10)->get();
        $medicationLogs = MedicationLog::where('patient_id', $patient->id)->get();
        $taken = $medicationLogs->where('status', 'taken')->count();
        $totalLogs = max($medicationLogs->count(), 1);

        return $this->success([
            'latest_daily_status' => $patient->dailyStatuses()->latest()->first(),
            'risk_level' => $patient->dailyStatuses()->latest()->value('risk_level') ?? 'stable',
            'medications_today' => $patient->medications()->where('is_active', true)->get(),
            'adherence_percentage' => round(($taken / $totalLogs) * 100, 2),
            'notifications' => $notifications,
            'active_doctor' => $activeDoctor,
            'active_caregiver' => $activeCaregiver,
            'appointments' => Appointment::where('patient_id', $patient->id)->latest()->take(5)->get(),
            'daily_tasks' => [
                ['label' => 'Submit daily status', 'done' => (bool) $patient->dailyStatuses()->whereDate('created_at', today())->exists()],
                ['label' => 'Review medications', 'done' => false],
            ],
        ]);
    }

    public function doctor(Request $request)
    {
        $doctor = $request->user()->doctor;
        abort_unless($doctor, 403);

        $relationships = PatientDoctorRelationship::with('patient.user')
            ->where('doctor_id', $doctor->id)
            ->get();

        $activePatientIds = $relationships->where('status', 'active')->pluck('patient_id');
        $statuses = DailyStatus::whereIn('patient_id', $activePatientIds)->latest()->take(10)->get();
        $medicationLogs = MedicationLog::whereIn('patient_id', $activePatientIds)->get();
        $taken = $medicationLogs->where('status', 'taken')->count();
        $total = max($medicationLogs->count(), 1);

        return $this->success([
            'total_assigned_patients' => $relationships->where('status', 'active')->count(),
            'high_risk_patients' => $statuses->where('risk_level', 'high_risk')->count(),
            'pending_follow_requests' => $relationships->where('status', 'pending')->count(),
            'reports_count' => Report::where('doctor_id', $doctor->id)->count(),
            'average_adherence' => round(($taken / $total) * 100, 2),
            'appointments' => Appointment::where('doctor_id', $doctor->id)->latest()->take(5)->get(),
            'recent_daily_statuses' => $statuses,
            'risk_trends' => $statuses->groupBy('risk_level')->map->count(),
            'patients' => $relationships,
        ]);
    }

    public function caregiver(Request $request)
    {
        $caregiver = $request->user()->caregiver;
        abort_unless($caregiver, 403);

        $relationships = $caregiver->patientRelationships()->with('patient.user')->where('status', 'active')->get();
        $patientIds = $relationships->pluck('patient_id');
        $todayMissed = MedicationLog::whereIn('patient_id', $patientIds)->whereDate('created_at', today())->where('status', 'missed')->count();
        $attention = DailyStatus::whereIn('patient_id', $patientIds)->whereIn('risk_level', ['attention_needed', 'moderate_risk', 'high_risk'])->count();

        return $this->success([
            'assigned_patients' => $relationships,
            'missed_medications_today' => $todayMissed,
            'attention_needed_cases' => $attention,
            'support_alerts' => UserNotification::where('user_id', $request->user()->id)->latest()->take(10)->get(),
            'daily_tasks' => [
                ['label' => 'Review missed medications', 'done' => false],
                ['label' => 'Check patient alerts', 'done' => false],
            ],
            'adherence_overview' => MedicationLog::whereIn('patient_id', $patientIds)->selectRaw("status, count(*) as total")->groupBy('status')->get(),
            'patient_status_summary' => DailyStatus::whereIn('patient_id', $patientIds)->latest()->take(10)->get(),
        ]);
    }

    public function admin()
    {
        return $this->success([
            'total_users' => User::count(),
            'total_patients' => User::where('role', 'patient')->count(),
            'total_doctors' => User::where('role', 'doctor')->count(),
            'total_caregivers' => User::where('role', 'caregiver')->count(),
            'pending_doctor_verifications' => Doctor::where('verification_status', 'pending')->count(),
            'active_alerts' => UserNotification::where('is_read', false)->count(),
            'high_risk_cases' => DailyStatus::where('risk_level', 'high_risk')->count(),
            'recent_registrations' => User::latest()->take(10)->get(),
            'suspicious_login_attempts' => LoginAttempt::where('successful', false)->latest()->take(10)->get(),
            'system_activity' => SystemActivityLog::latest('created_at')->take(20)->get(),
            'reports_overview' => Report::latest()->take(10)->get(),
            'appointments_overview' => Appointment::latest()->take(10)->get(),
        ]);
    }
}
