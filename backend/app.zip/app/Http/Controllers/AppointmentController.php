<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\AppointmentBookingLog;
use App\Models\Doctor;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    public function __construct(private readonly NotificationService $notificationService)
    {
    }

    public function index(Request $request)
    {
        $user = $request->user();
        $query = Appointment::with(['patient.user', 'doctor.user', 'hospital']);

        if ($user->role === 'patient' && $user->patient) {
            $query->where('patient_id', $user->patient->id);
        } elseif ($user->role === 'doctor' && $user->doctor) {
            $query->where('doctor_id', $user->doctor->id);
        }

        return $this->success($query->latest()->get());
    }

    public function store(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 403);

        $data = $request->validate([
            'doctor_id' => ['required', 'exists:doctors,id'],
            'hospital_id' => ['nullable', 'exists:hospitals,id'],
            'appointment_date' => ['required', 'date'],
            'appointment_time' => ['required', 'date_format:H:i'],
            'type' => ['nullable', 'string'],
            'amount' => ['nullable', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string'],
        ]);

        $appointment = Appointment::create([
            ...$data,
            'patient_id' => $patient->id,
            'amount' => $data['amount'] ?? 0,
        ]);

        AppointmentBookingLog::create([
            'appointment_id' => $appointment->id,
            'user_id' => $request->user()->id,
            'action' => 'created',
            'notes' => $data['notes'] ?? null,
        ]);

        return $this->success($appointment, 'Appointment created successfully', 201);
    }

    public function show(Request $request, Appointment $appointment)
    {
        return $this->success($appointment->load(['patient.user', 'doctor.user', 'hospital']));
    }

    public function update(Request $request, Appointment $appointment)
    {
        $data = $request->validate([
            'appointment_date' => ['nullable', 'date'],
            'appointment_time' => ['nullable', 'date_format:H:i'],
            'type' => ['nullable', 'string'],
            'amount' => ['nullable', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string'],
            'status' => ['nullable', 'in:pending,confirmed,cancelled,completed'],
        ]);

        $appointment->update($data);
        return $this->success($appointment->fresh(), 'Appointment updated successfully');
    }

    public function confirm(Appointment $appointment) { return $this->updateStatus($appointment, 'confirmed'); }
    public function cancel(Appointment $appointment) { return $this->updateStatus($appointment, 'cancelled'); }
    public function complete(Appointment $appointment) { return $this->updateStatus($appointment, 'completed'); }

    public function pay(Appointment $appointment)
    {
        $appointment->update([
            'payment_status' => 'paid',
            'status' => 'confirmed',
        ]);

        if ($appointment->patient?->user) {
            $this->notificationService->create(
                $appointment->patient->user,
                'payment_success',
                'Payment successful',
                'Your appointment payment was marked as successful.',
                'success',
                Appointment::class,
                $appointment->id
            );
        }

        return $this->success($appointment->fresh(), 'Payment processed successfully');
    }

    public function paymentStatus(Appointment $appointment)
    {
        return $this->success([
            'appointment_id' => $appointment->id,
            'payment_status' => $appointment->payment_status,
            'status' => $appointment->status,
            'amount' => $appointment->amount,
        ]);
    }

    private function updateStatus(Appointment $appointment, string $status)
    {
        $appointment->update(['status' => $status]);
        return $this->success($appointment->fresh(), 'Appointment status updated successfully');
    }
}
