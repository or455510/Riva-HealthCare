<?php

namespace App\Http\Controllers;

use App\Models\Medication;
use App\Models\MedicationLog;
use App\Models\Patient;
use App\Models\PatientCaregiverRelationship;
use App\Models\PatientDoctorRelationship;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class MedicationController extends Controller
{
    public function __construct(private readonly NotificationService $notificationService)
    {
    }

    public function index(Request $request)
    {
        $patient = $this->resolvePatient($request);
        abort_unless($patient, 403);

        $medications = Medication::where('patient_id', $patient->id)->where('is_active', true)->latest()->get();
        return $this->success($medications);
    }

    public function store(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 403);

        $data = $request->validate([
            'name' => ['nullable', 'string', 'max:255'],
            'drug_name' => ['nullable', 'string', 'max:255'],
            'dosage' => ['required', 'string', 'max:255'],
            'schedule_time' => ['nullable', 'date_format:H:i'],
            'frequency' => ['nullable', 'string', 'max:255'],
            'instructions' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);

        $medication = Medication::create([
            'patient_id' => $patient->id,
            'name' => $data['name'] ?? $data['drug_name'] ?? 'Medication',
            'dosage' => $data['dosage'],
            'schedule_time' => $data['schedule_time'] ?? null,
            'frequency' => $data['frequency'] ?? 'daily',
            'instructions' => $data['instructions'] ?? $data['notes'] ?? null,
            'is_active' => true,
        ]);

        return $this->success($medication, 'Medication created successfully', 201);
    }

    public function show(Request $request, Medication $medication)
    {
        $this->authorizeMedicationAccess($request, $medication);
        return $this->success($medication);
    }

    public function update(Request $request, Medication $medication)
    {
        $this->authorizeMedicationOwner($request, $medication);

        $data = $request->validate([
            'name' => ['nullable', 'string', 'max:255'],
            'drug_name' => ['nullable', 'string', 'max:255'],
            'dosage' => ['nullable', 'string', 'max:255'],
            'schedule_time' => ['nullable', 'date_format:H:i'],
            'frequency' => ['nullable', 'string', 'max:255'],
            'instructions' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $medication->update([
            'name' => $data['name'] ?? $data['drug_name'] ?? $medication->name,
            'dosage' => $data['dosage'] ?? $medication->dosage,
            'schedule_time' => $data['schedule_time'] ?? $medication->schedule_time,
            'frequency' => $data['frequency'] ?? $medication->frequency,
            'instructions' => $data['instructions'] ?? $data['notes'] ?? $medication->instructions,
            'is_active' => $data['is_active'] ?? $medication->is_active,
        ]);

        return $this->success($medication->fresh(), 'Medication updated successfully');
    }

    public function destroy(Request $request, Medication $medication)
    {
        $this->authorizeMedicationOwner($request, $medication);
        $medication->update(['is_active' => false]);

        return $this->success(null, 'Medication deleted successfully');
    }

    public function take(Request $request, Medication $medication) { return $this->mark($request, $medication, 'taken'); }
    public function snooze(Request $request, Medication $medication) { return $this->mark($request, $medication, 'snoozed'); }
    public function missed(Request $request, Medication $medication) { return $this->mark($request, $medication, 'missed'); }
    public function needHelp(Request $request, Medication $medication) { return $this->mark($request, $medication, 'need_help'); }

    public function adherenceSummary(Request $request)
    {
        $patient = $this->resolvePatient($request);
        abort_unless($patient, 403);

        $logs = MedicationLog::where('patient_id', $patient->id)->get();
        $total = max($logs->count(), 1);
        $taken = $logs->where('status', 'taken')->count();

        return $this->success([
            'total_logs' => $logs->count(),
            'taken_logs' => $taken,
            'adherence_percentage' => round(($taken / $total) * 100, 2),
        ]);
    }

    public function detectMissed()
    {
        $logs = MedicationLog::query()
            ->whereNull('status')
            ->where('scheduled_at', '<', now()->subHour())
            ->get();

        foreach ($logs as $log) {
            $log->update(['status' => 'missed']);
            $this->notifySupportNetwork($log->patient, 'medication_missed', 'Medication missed', 'A scheduled medication was missed.', 'warning', MedicationLog::class, $log->id);
        }

        return $this->success([
            'updated_logs' => $logs->count(),
        ], 'Missed medications detected');
    }

    private function mark(Request $request, Medication $medication, string $status)
    {
        $this->authorizeMedicationOwner($request, $medication);

        $log = MedicationLog::create([
            'medication_id' => $medication->id,
            'patient_id' => $medication->patient_id,
            'scheduled_at' => now(),
            'taken_at' => $status === 'taken' ? now() : null,
            'status' => $status,
            'confirmed_by' => $request->user()->id,
        ]);

        if (in_array($status, ['missed', 'need_help'], true)) {
            $severity = $status === 'need_help' ? 'high' : 'warning';
            $message = $status === 'need_help'
                ? 'A patient requested help with medication.'
                : 'A patient missed a medication dose.';

            $this->notifySupportNetwork($medication->patient, 'medication_'.$status, ucfirst(str_replace('_', ' ', $status)), $message, $severity, MedicationLog::class, $log->id);
        }

        return $this->success($log, 'Medication status updated successfully');
    }

    private function notifySupportNetwork(Patient $patient, string $type, string $title, string $message, string $severity, string $relatedType, int $relatedId): void
    {
        PatientDoctorRelationship::with('doctor.user')
            ->where('patient_id', $patient->id)
            ->where('status', 'active')
            ->get()
            ->each(fn ($relationship) => $relationship->doctor?->user
                ? $this->notificationService->create($relationship->doctor->user, $type, $title, $message, $severity, $relatedType, $relatedId)
                : null);

        PatientCaregiverRelationship::with('caregiver.user')
            ->where('patient_id', $patient->id)
            ->where('status', 'active')
            ->get()
            ->each(fn ($relationship) => $relationship->caregiver?->user
                ? $this->notificationService->create($relationship->caregiver->user, $type, $title, $message, $severity, $relatedType, $relatedId)
                : null);
    }

    private function resolvePatient(Request $request): ?Patient
    {
        $user = $request->user();
        return $user->patient;
    }

    private function authorizeMedicationAccess(Request $request, Medication $medication): void
    {
        if ($request->user()->role === 'patient') {
            abort_unless($request->user()->patient?->id === $medication->patient_id, 403);
            return;
        }
    }

    private function authorizeMedicationOwner(Request $request, Medication $medication): void
    {
        abort_unless($request->user()->patient?->id === $medication->patient_id, 403);
    }
}
