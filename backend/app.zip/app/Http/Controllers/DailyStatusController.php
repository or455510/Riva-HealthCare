<?php

namespace App\Http\Controllers;

use App\Models\DailyStatus;
use App\Models\Patient;
use App\Models\PatientCaregiverRelationship;
use App\Models\PatientDoctorRelationship;
use App\Services\NotificationService;
use App\Services\RiskAssessmentService;
use Illuminate\Http\Request;

class DailyStatusController extends Controller
{
    public function __construct(
        private readonly RiskAssessmentService $riskAssessmentService,
        private readonly NotificationService $notificationService
    ) {
    }

    public function index(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 403);

        return $this->success($patient->dailyStatuses()->latest()->get());
    }

    public function store(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 403);

        $data = $request->validate([
            'mood' => ['nullable', 'string', 'max:255'],
            'date' => ['nullable', 'date'],
            'pain_level' => ['nullable', 'integer', 'min:0', 'max:10'],
            'sleep_hours' => ['nullable', 'integer', 'min:0', 'max:24'],
            'sleep_quality' => ['nullable', 'string', 'max:255'],
            'weight' => ['nullable', 'numeric', 'min:0', 'max:300'],
            'blood_pressure_systolic' => ['nullable', 'integer', 'min:60', 'max:240'],
            'blood_pressure_diastolic' => ['nullable', 'integer', 'min:30', 'max:160'],
            'temperature' => ['nullable', 'numeric', 'min:30', 'max:45'],
            'heart_rate' => ['nullable', 'integer', 'min:20', 'max:240'],
            'symptoms' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'medication_taken' => ['nullable'],
            'additional_data' => ['nullable', 'array'],
        ]);

        $data['date'] = $data['date'] ?? now()->toDateString();
        $data['pain_level'] = $data['pain_level'] ?? 0;
        $data['risk_level'] = $this->riskAssessmentService->classify($data, $patient);
        $data['medication_taken'] = $this->normalizeMedicationTaken($data['medication_taken'] ?? null);
        $status = DailyStatus::updateOrCreate(
            ['patient_id' => $patient->id, 'date' => $data['date']],
            $data
        );

        $notifications = $this->dispatchRiskNotifications($patient, $status);

        return $this->success([
            'status' => $status,
            'risk_level' => $status->risk_level,
            'notifications' => $notifications,
        ], 'Daily status saved successfully', 201);
    }

    public function latest(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 403);

        return $this->success($patient->dailyStatuses()->latest()->first());
    }

    public function patientStatuses(Request $request, Patient $patient)
    {
        $user = $request->user();
        abort_unless(in_array($user->role, ['doctor', 'caregiver', 'admin'], true), 403);

        return $this->success($patient->dailyStatuses()->latest()->get());
    }

    private function dispatchRiskNotifications(Patient $patient, DailyStatus $status): array
    {
        $created = [];

        if ($status->risk_level === 'stable') {
            return $created;
        }

        $caregiverRelationships = PatientCaregiverRelationship::with('caregiver.user')
            ->where('patient_id', $patient->id)
            ->where('status', 'active')
            ->get();

        foreach ($caregiverRelationships as $relationship) {
            if ($relationship->caregiver?->user) {
                $created[] = $this->notificationService->create(
                    $relationship->caregiver->user,
                    'daily_status_risk',
                        'Patient needs attention',
                        'A patient daily status requires attention.',
                        ['risk_level' => $status->risk_level, 'daily_status_id' => $status->id],
                        '/notifications/' . $status->id,
                        'alerts'
                    );
            }
        }

        if (in_array($status->risk_level, ['moderate_risk', 'high_risk'], true)) {
            $doctorRelationships = PatientDoctorRelationship::with('doctor.user')
                ->where('patient_id', $patient->id)
                ->where('status', 'active')
                ->get();

            foreach ($doctorRelationships as $relationship) {
                if ($relationship->doctor?->user) {
                    $created[] = $this->notificationService->create(
                        $relationship->doctor->user,
                        'daily_status_risk',
                        'Patient risk alert',
                        'A patient daily status requires review.',
                        ['risk_level' => $status->risk_level, 'daily_status_id' => $status->id],
                        '/notifications/' . $status->id,
                        'alerts'
                    );
                }
            }
        }

        return $created;
    }

    private function normalizeMedicationTaken(mixed $value): bool
    {
        return in_array($value, [true, 1, '1', 'yes', 'taken'], true);
    }
}
