import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../../service/auth.service';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule, CommonModule, FormsModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css',
})
export class ContactComponent implements OnInit {
  
  userRole: string = 'patient'; // ✅ default value بدل ما تكون فاضية
  sidebarLinks: { icon: string; route: string }[] = [];

  constructor(private authService: AuthService) {}

ngOnInit(): void {
  const role = this.authService.getUserRole();
  
  // 🔍 أول حاجة: اطبع إيه اللي بيرجع من الـ service
  console.log('Role from service:', role);
  
  // لو مفيش role خالص، متعملش sidebar
  if (!role || role.trim() === '') {
    this.sidebarLinks = [];
    return;
  }
  
  this.userRole = role.trim().toLowerCase();
  this.setSidebarLinks();
}

  setSidebarLinks() {
    if (this.userRole === 'caregiver') {
      this.sidebarLinks = [
        { icon: 'fas fa-home', route: '/dashboard-caregiver' },
        { icon: 'fa-brands fa-rocketchat', route: '/chat-c' },
        { icon: 'fa-solid fa-circle-user', route: '/myprofile' },
        { icon: 'fa-solid fa-phone', route: '/contact' },
        { icon: 'fa-solid fa-bed-pulse', route: '/patient-cards' }
      ];
    } else if (this.userRole === 'doctor') {
      this.sidebarLinks = [
        { icon: 'fas fa-home', route: '/dashboard' },
        { icon: 'fa-brands fa-rocketchat', route: '/chat' },
        { icon: 'fa-solid fa-circle-user', route: '/myprofile' },
        { icon: 'fa-solid fa-phone', route: '/contact' },
        { icon: 'fa-solid fa-bed-pulse', route: '/patient-cards' }
      ];
    } else if (this.userRole === 'patient') 
      { this.sidebarLinks = [
        { icon: 'fas fa-home', route: '/dashboard-p' },
        { icon: 'fas fa-pills', route: '/add-new-medication' },
        { icon: 'fa-solid fa-user-doctor', route: '/doctor-cards' },
        { icon: 'fa-brands fa-rocketchat', route: '/chat' },
        { icon: 'fa-solid fa-circle-user', route: '/myprofile' },
        { icon: 'fa-solid fa-user-nurse', route: '/caregiver-cards' }
    ] } else {
      this.sidebarLinks = [
        
      ];
    }
  }
}