import { Component, AfterViewInit, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { routes } from '../../../app.routes';

interface HealthTip {
  title: string;
  text: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements AfterViewInit {

  healthTips: HealthTip[] = [
    { title: 'Stay Hydrated!', text: 'Drinking 8 glasses of water daily helps regulate blood pressure.' },
    { title: 'Check Your Sugar', text: 'Regular monitoring helps you understand your body better.' },
    { title: 'Walk Regularly', text: 'A 15-minute walk after meals improves digestion significantly.' },
    { title: 'Sleep Well', text: '7-8 hours of sleep helps manage stress hormones.' },
  ];

  currentIndex = 0;

  constructor(private zone: NgZone,    private router: Router,) {}

  nextTip(): void {
    // Fade out → swap → fade in
    const tipContent = document.querySelector('.tip-banner .flex-1') as HTMLElement;
    if (tipContent) {
      tipContent.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
      tipContent.style.opacity = '0';
      tipContent.style.transform = 'translateY(10px)';
      setTimeout(() => {
        this.currentIndex = (this.currentIndex + 1) % this.healthTips.length;
        setTimeout(() => {
          tipContent.style.opacity = '1';
          tipContent.style.transform = 'translateY(0)';
        }, 20);
      }, 260);
    } else {
      this.currentIndex = (this.currentIndex + 1) % this.healthTips.length;
    }
  }

  get currentTip(): HealthTip {
    return this.healthTips[this.currentIndex];
  }
goToSignin() {
  this.router.navigate(['/signin']);
}
goToContact() {
  this.router.navigate(['/contact']);
}

  ngAfterViewInit(): void {
    // Run outside Angular to avoid unnecessary change detection cycles
    this.zone.runOutsideAngular(() => {
      this.initScrollReveal();
      this.initMarqueeHover();
      this.initCardTilt();
      this.initMagneticButtons();
      this.initStepConnector();
    });
  }

  /* ── 1. Scroll-reveal with IntersectionObserver ─────────── */
  private initScrollReveal(): void {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.10, rootMargin: '0px 0px -40px 0px' }
    );

    document
      .querySelectorAll(
        '.reveal, .reveal-left, .step-item, .testimonial-card, .section-heading'
      )
      .forEach((el) => observer.observe(el));
  }

  /* ── 2. Marquee pause-on-hover ──────────────────────────── */
  private initMarqueeHover(): void {
    document.querySelectorAll('.animate-marquee').forEach((marquee) => {
      const parent = marquee.parentElement;
      if (!parent) return;
      const el = marquee as HTMLElement;
      parent.addEventListener('mouseenter', () => { el.style.animationPlayState = 'paused'; });
      parent.addEventListener('mouseleave', () => { el.style.animationPlayState = 'running'; });
    });
  }

  /* ── 3. Subtle 3D tilt on health + testimonial cards ───── */
  private initCardTilt(): void {
    const TILT_MAX = 8; // degrees
    const cards = document.querySelectorAll<HTMLElement>(
      '.health-card, .testimonial-card'
    );

    cards.forEach((card) => {
      card.addEventListener('mousemove', (e: MouseEvent) => {
        const rect = card.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width  - 0.5; // -0.5 → 0.5
        const y = (e.clientY - rect.top)  / rect.height - 0.5;
        const rotX = (-y * TILT_MAX).toFixed(2);
        const rotY = ( x * TILT_MAX).toFixed(2);
        card.style.transform =
          `translateY(-14px) scale(1.02) rotateX(${rotX}deg) rotateY(${rotY}deg)`;
        card.style.transition = 'transform 0.08s linear, box-shadow 0.08s linear';
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = '';
        card.style.transition = '';
      });
    });
  }

  /* ── 4. Magnetic pull on primary CTA button ─────────────── */
  private initMagneticButtons(): void {
    const PULL_STRENGTH = 0.35;
    document
      .querySelectorAll<HTMLElement>('.hero-cta button:first-child, .tip-btn')
      .forEach((btn) => {
        btn.addEventListener('mousemove', (e: MouseEvent) => {
          const rect = btn.getBoundingClientRect();
          const cx = rect.left + rect.width / 2;
          const cy = rect.top  + rect.height / 2;
          const dx = (e.clientX - cx) * PULL_STRENGTH;
          const dy = (e.clientY - cy) * PULL_STRENGTH;
          btn.style.transform = `translate(${dx}px, ${dy}px) scale(1.06)`;
          btn.style.transition = 'transform 0.15s ease, box-shadow 0.15s ease';
        });

        btn.addEventListener('mouseleave', () => {
          btn.style.transform = '';
          btn.style.transition = '';
        });
      });
  }

  /* ── 5. Animated connector line between steps ───────────── */
  private initStepConnector(): void {
    const stepsWrapper = document.querySelector<HTMLElement>(
      '.py-16.bg-white .flex.flex-col'
    );
    if (!stepsWrapper) return;

    // Only on desktop (md+)
    if (window.innerWidth < 768) return;

    const line = document.createElement('div');
    line.style.cssText = `
      position: absolute;
      top: 32px; left: 10%; right: 10%;
      height: 2px;
      background: linear-gradient(90deg, #e0f2fe, #38bdf8, #2563eb, #38bdf8, #e0f2fe);
      background-size: 200% 100%;
      border-radius: 2px;
      animation: lineFlow 3s linear infinite;
      pointer-events: none;
      z-index: 0;
    `;

    // Add keyframe via style tag
    const styleEl = document.createElement('style');
    styleEl.textContent = `
      @keyframes lineFlow {
        0%   { background-position: 200% 0; }
        100% { background-position: -200% 0; }
      }
    `;
    document.head.appendChild(styleEl);

    stepsWrapper.style.position = 'relative';
    stepsWrapper.insertBefore(line, stepsWrapper.firstChild);
  }
}