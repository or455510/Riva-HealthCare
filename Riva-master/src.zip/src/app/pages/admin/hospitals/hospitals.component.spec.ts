import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HospitalsComponent } from './hospitals.component';

describe('HospitalsComponent', () => {
  let component: HospitalsComponent;
  let fixture: ComponentFixture<HospitalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HospitalsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HospitalsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
