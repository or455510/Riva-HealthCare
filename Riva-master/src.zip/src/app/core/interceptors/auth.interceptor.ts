import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token =
    typeof window !== 'undefined'
      ? localStorage.getItem('token')
      : null;

  if (!token) {
    return next(req);
  }

  // ✅ لو FormData متضيفيش Content-Type خالص
  const isFormData = req.body instanceof FormData;

  return next(
    req.clone({
      setHeaders: isFormData
        ? { Authorization: `Bearer ${token}`, Accept: 'application/json' }
        : { Authorization: `Bearer ${token}`, Accept: 'application/json', 'Content-Type': 'application/json' },
    })
  );
};