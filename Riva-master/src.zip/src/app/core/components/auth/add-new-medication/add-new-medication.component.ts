import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { finalize } from 'rxjs';
import { API_BASE_URL } from '../../../../constants';

interface Medication {
  id?: number;
  drug_name: string;
  dosage: string;
  schedule_time: string;
  frequency: string;
  notes: string;
}

interface MedicalRecord {
  id?: number;
  title: string;
  date: string;
  file?: File;
  file_preview?: string;
  file_type?: string;
}

@Component({
  selector: 'app-add-new-medication',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule, HttpClientModule],
  templateUrl: './add-new-medication.component.html',
})
export class AddNewMedicationComponent implements OnInit {

  private apiUrl = `${API_BASE_URL}/medications`;

  medications: Medication[] = [];
  medicalRecords: MedicalRecord[] = [];

  isLoading = false;
  isSaving = false;
  errorMessage = '';
  successMessage = '';

  newMedication: Medication = {
    drug_name: '',
    dosage: '',
    schedule_time: '',
    frequency: 'daily',
    notes: '',
  };

  newRecord: MedicalRecord = {
    title: '',
    date: ''
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadMedications();
  }

  private getToken(): string {
    return localStorage.getItem('token') || '';
  }

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      Authorization: `Bearer ${this.getToken()}`,
      Accept: 'application/json',
      'Content-Type': 'application/json'
    });
  }

  loadMedications(): void {
    this.isLoading = true;
    this.http.get<any>(this.apiUrl, { headers: this.getHeaders() })
    .pipe(finalize(() => this.isLoading = false))
    .subscribe({
      next: (res) => this.medications = res?.data || res || [],
      error: (err) => this.errorMessage = 'Failed to load medications'
    });
  }

  // معالجة اختيار الملف (صورة أو PDF)
  onFileSelected(event: any): void {
    const file: File = event.target.files[0];
    if (file) {
      this.newRecord.file = file;
      this.newRecord.file_type = file.type;
      
      // إنشاء معاينة إذا كانت صورة
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e: any) => this.newRecord.file_preview = e.target.result;
        reader.readAsDataURL(file);
      } else {
        this.newRecord.file_preview = undefined; // للـ PDF لا نحتاج معاينة صورة
      }
    }
  }

  saveMedication(): void {
    if (!this.newMedication.drug_name || !this.newMedication.dosage) {
      this.errorMessage = 'Please fill required fields';
      return;
    }

    this.isSaving = true;
    this.http.post(this.apiUrl, this.newMedication, { headers: this.getHeaders() })
    .pipe(finalize(() => this.isSaving = false))
    .subscribe({
      next: (res: any) => {
        this.medications.push(res?.data || res);
        this.successMessage = 'Medication saved successfully';
        this.resetForm();
      },
      error: (err) => this.errorMessage = 'Save failed'
    });
  }

  addMedicalRecord(): void {
    if (!this.newRecord.title || !this.newRecord.file) {
      this.errorMessage = 'Please provide a title and select a file (PDF/Image)';
      return;
    }
    
    // محاكاة الإضافة (يجب ربطها بـ FormData API لرفع الملفات حقيقةً)
    this.medicalRecords.push({ ...this.newRecord, id: Date.now() });
    this.successMessage = 'Medical record added successfully';
    this.newRecord = { title: '', date: '' };
    (document.getElementById('fileInput') as HTMLInputElement).value = '';
  }

  deleteMedication(id?: number, index?: number): void {
    if (!id) return;
    this.http.delete(`${this.apiUrl}/${id}`, { headers: this.getHeaders() })
    .subscribe({
      next: () => this.medications.splice(index!, 1),
      error: () => this.errorMessage = 'Delete failed'
    });
  }

  resetForm(): void {
    this.newMedication = { drug_name: '', dosage: '', schedule_time: '', frequency: 'daily', notes: '' };
  }
}