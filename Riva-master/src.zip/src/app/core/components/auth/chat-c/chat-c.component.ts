import {
  Component, OnInit, OnDestroy, ViewChild, ElementRef,
  AfterViewChecked, CUSTOM_ELEMENTS_SCHEMA,
  ChangeDetectorRef, inject
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthService } from '../../../../service/auth.service';
import { interval, Subscription, of } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { API_BASE_URL } from '../../../../constants';

export interface Message {
  id?: number;
  sender_id?: number;
  receiver_id?: number;
  body: string;
  created_at?: string;
}

export interface ChatContact {
  id: number;
  name: string;
  avatar: string;
  lastMessage?: string;
  status: 'online' | 'offline';
}

const STORAGE_BASE = 'http://127.0.0.1:8000/storage/';

function toAvatarUrl(user: any, fallback: string): string {
  return user.profile_image_url
    || (user.profile_image ? `${STORAGE_BASE}${user.profile_image}` : null)
    || fallback;
}

@Component({
  selector: 'app-chat-c',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule, HttpClientModule],
  templateUrl: './chat-c.component.html',
  styleUrls: ['./chat-c.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ChatCComponent implements OnInit, OnDestroy, AfterViewChecked {

  @ViewChild('messagesContainer') messagesContainer!: ElementRef;
  private cdr = inject(ChangeDetectorRef);

  userRole: 'patient' | 'caregiver' | 'doctor' = 'patient';
  get isCaregiver(): boolean { return this.userRole === 'caregiver'; }
  get isPatient():   boolean { return this.userRole === 'patient'; }
  get isDoctor():    boolean { return this.userRole === 'doctor'; }
  get contactsLabel(): string { return this.isCaregiver ? 'My Patients' : 'My Caregivers'; }

  sidebarLinks: { icon: string; route: string }[] = [];
  myUserId: number | null = null;
  contacts: ChatContact[] = [];
  selectedContact: ChatContact | null = null;
  isLoadingContacts = true;
  messages: Message[] = [];
  newMessage = '';
  isLoading = false;
  isSending = false;
  showTip = false;

  private pollingSubscription!: Subscription;
  private shouldScrollToBottom = false;

  constructor(private http: HttpClient, private authService: AuthService) {}

  ngOnInit(): void { this.resolveRole(); this.loadCurrentUser(); }

  private resolveRole(): void {
    const role = this.authService.getUserRole().toLowerCase();
    this.userRole = role === 'caregiver' ? 'caregiver' : role === 'doctor' ? 'doctor' : 'patient';

    if (this.isCaregiver) {
      this.sidebarLinks = [
        { icon: 'fas fa-home',              route: '/dashboard-caregiver' },
        { icon: 'fa-brands fa-rocketchat',  route: '/chat-c' },
        { icon: 'fa-solid fa-circle-user',  route: '/myprofile' },
        { icon: 'fa-solid fa-phone',        route: '/contact' },
        { icon: 'fa-solid fa-bed-pulse',    route: '/patient-cards' },
      ];
    } else if (this.isDoctor) {
      this.sidebarLinks = [
        { icon: 'fas fa-home',              route: '/dashboard' },
        { icon: 'fa-brands fa-rocketchat',  route: '/chat-c' },
        { icon: 'fa-solid fa-circle-user',  route: '/myprofile' },
        { icon: 'fa-solid fa-phone',        route: '/contact' },
        { icon: 'fa-solid fa-bed-pulse',    route: '/patient-cards' },
      ];
    } else {
      this.sidebarLinks = [
        { icon: 'fas fa-home',              route: '/dashboard-p' },
        { icon: 'fas fa-pills',             route: '/add-new-medication' },
        { icon: 'fa-solid fa-user-doctor',  route: '/doctor-cards' },
        { icon: 'fa-solid fa-hands-holding-heart', route: '/caregiver-cards' },
        { icon: 'fa-brands fa-rocketchat',  route: '/chat' },
        { icon: 'fa-solid fa-circle-user',  route: '/myprofile' },
      ];
    }
  }

private loadCurrentUser(): void {
    try {
      const stored = localStorage.getItem('user');
      if (stored) {
        const obj = JSON.parse(stored);
        this.myUserId = obj?.id || null;
      }
    } catch {}

    // ✅ حمل الـ contacts فوراً من غير ما تستنى الـ me()
    this.loadContacts();

    this.authService.me().subscribe({
      next: (res) => {
        const resAny = res as any;
        this.myUserId = resAny?.user?.id ?? resAny?.id ?? this.myUserId;
      },
      error: () => {
        this.myUserId = this.authService.getUser()?.id || this.myUserId;
      }
    });
  }

  loadContacts(): void {
    this.isLoadingContacts = true;
    const headers = { Authorization: `Bearer ${this.authService.getToken()}` };

    if (this.isCaregiver) {
      this.http.get<any>(`${API_BASE_URL}/dashboard/caregiver`, { headers }).subscribe({
        next: (res) => {
          const list = res.data?.assigned_patients || [];
          this.contacts = list.map((r: any) => {
            const user = r.patient?.user || {};
            const name = `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'Patient';
            return { id: user.id || r.patient_id, name, avatar: toAvatarUrl(user, `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=F5F0FF&color=7C3AED`), status: 'online' as const };
          });
          this.isLoadingContacts = false;
          if (this.contacts.length > 0) this.selectContact(this.contacts[0]);
        },
        error: () => { this.isLoadingContacts = false; }
      });
    } else {
      this.http.get<any>(`${API_BASE_URL}/dashboard/patient`, { headers }).subscribe({
        next: (res) => {
          const contacts: any[] = [];
          const ac = res.data?.active_caregiver?.caregiver;
          if (ac) {
            const user = ac.user || {};
            const name = `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'Caregiver';
            contacts.push({ id: user.id || ac.user_id, name, avatar: toAvatarUrl(user, `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=F5F0FF&color=7C3AED`), status: 'online' as const });
          }
          this.contacts = contacts;
          this.isLoadingContacts = false;
          if (this.contacts.length > 0) this.selectContact(this.contacts[0]);
        },
        error: () => { this.isLoadingContacts = false; }
      });
    }
  }

  selectContact(contact: ChatContact): void {
    this.selectedContact = contact; this.messages = []; this.isLoading = true;
    this.pollingSubscription?.unsubscribe();
    this.loadMessages(contact.id); this.startPolling(contact.id);
  }

  loadMessages(contactId: number): void {
    this.http.get<any>(`${API_BASE_URL}/messages/${contactId}`, { headers: { Authorization: `Bearer ${this.authService.getToken()}` } }).subscribe({
      next: (res) => { this.messages = Array.isArray(res) ? res : res?.data || []; this.isLoading = false; this.shouldScrollToBottom = true; },
      error: () => { this.isLoading = false; this.messages = []; }
    });
  }

  private startPolling(contactId: number): void {
    this.pollingSubscription = interval(5000).pipe(
      switchMap(() => this.http.get<any>(`${API_BASE_URL}/messages/${contactId}`, { headers: { Authorization: `Bearer ${this.authService.getToken()}` } }).pipe(catchError(() => of({ data: this.messages }))))
    ).subscribe((res) => {
      const msgs = Array.isArray(res) ? res : res?.data || this.messages;
      if (msgs[msgs.length - 1]?.id !== this.messages[this.messages.length - 1]?.id) { this.messages = msgs; this.shouldScrollToBottom = true; }
    });
  }

  sendMessage(): void {
    const content = this.newMessage.trim();
    if (!content || !this.selectedContact) return;
    const optimistic: Message = { sender_id: this.myUserId ?? undefined, receiver_id: this.selectedContact.id, body: content, created_at: new Date().toISOString() };
    this.messages = [...this.messages, optimistic]; this.newMessage = ''; this.isSending = true; this.shouldScrollToBottom = true;
    this.http.post<any>(`${API_BASE_URL}/messages`, { receiver_id: this.selectedContact.id, body: content }, { headers: { Authorization: `Bearer ${this.authService.getToken()}` } }).subscribe({
      next: (res) => { const saved = res?.data || res; const idx = this.messages.indexOf(optimistic); if (idx !== -1 && saved?.id) { const updated = [...this.messages]; updated[idx] = saved; this.messages = updated; } this.isSending = false; this.shouldScrollToBottom = true; },
      error: () => { this.isSending = false; }
    });
  }

  onKeyDown(e: KeyboardEvent): void { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.sendMessage(); } }
  formatTime(ts: string): string { try { return new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }); } catch { return ''; } }

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      try { const el = this.messagesContainer?.nativeElement; if (el) el.scrollTop = el.scrollHeight; } catch {}
      this.shouldScrollToBottom = false; this.cdr.detectChanges();
    }
  }

  ngOnDestroy(): void { this.pollingSubscription?.unsubscribe(); }
}