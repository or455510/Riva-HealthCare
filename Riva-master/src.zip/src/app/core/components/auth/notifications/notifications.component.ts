import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { AuthService } from '../../../../service/auth.service';
import { API_BASE_URL } from '../../../../constants';
import { MissedMedicationService } from '../../../../service/missed-medication.service';
import { NotificationService } from '../../../../service/notification.service';
import { NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

interface Notification {
  id: number | string;
  type: 'medication' | 'test' | 'doctor' | 'general';
  title: string;
  time: string;
  iconBg: string;
  read_at: string | null;
  isMissedLocal?: boolean;
  targetRole?: 'patient' | 'doctor' | 'caregiver' | 'all';
}

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, RouterModule],
  templateUrl: './notifications.component.html'
})
export class NotificationsComponent implements OnInit, OnDestroy {

  notifications: Notification[] = [];
  isLoading = true;
  overallEnabled = true;
  currentRole: 'patient' | 'doctor' | 'caregiver' = 'patient';

  categoryFilters = {
    Medication: true,
    Tests:      true,
    Messages:   true,
  };

  get filteredNotifications(): Notification[] {
    return this.notifications.filter(n => {
      if (n.type === 'medication' && this.currentRole !== 'patient') return false;
      if (n.isMissedLocal         && this.currentRole !== 'patient') return false;
      if (n.targetRole && n.targetRole !== 'all' && n.targetRole !== this.currentRole) return false;
      if (!this.overallEnabled) return false;
      if (n.type === 'medication' && !this.categoryFilters.Medication) return false;
      if (n.type === 'test'       && !this.categoryFilters.Tests)      return false;
      if (n.type === 'general'    && !this.categoryFilters.Messages)   return false;
      return true;
    });
  }

  private missedSub!: Subscription;
  private appNotifSub!: Subscription;

  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private router: Router,
    private missedMedService: MissedMedicationService,
    private appNotifService: NotificationService
  ) {}

  private get authHeaders() {
    return { Authorization: `Bearer ${this.authService.getToken()}` };
  }

  ngOnInit(): void {
    const role = this.authService.getUserRole?.()?.toLowerCase() || 'patient';
    this.currentRole = role.includes('doctor')    ? 'doctor'
                     : role.includes('caregiver') ? 'caregiver'
                     : 'patient';

    this.loadNotifications();

    this.missedSub = this.missedMedService.missed$.subscribe(missedList => {
      this.notifications = this.notifications.filter(n => !n.isMissedLocal);
      const missedNotifs: Notification[] = missedList.map(m => ({
        id:            `missed-${m.id}`,
        type:          'medication' as const,
        title:         `⚠️ Missed medication: ${m.medicationName} — was due at ${m.scheduleTime}`,
        time:          new Date(m.reportedAt).toLocaleString('en-GB', {
                         hour: '2-digit', minute: '2-digit',
                         day: 'numeric',  month: 'short'
                       }),
        iconBg:        'bg-red-500',
        read_at:       null,
        isMissedLocal: true,
        targetRole:    'patient' as const
      }));
      this.notifications = [...missedNotifs, ...this.notifications];
    });

    this.appNotifSub = this.appNotifService.notification$.subscribe(appNotif => {
      let targetRole: Notification['targetRole'] = 'all';

      if (appNotif.type === 'message') {
        targetRole = this.currentRole;
      } else if (appNotif.type === 'medication') {
        targetRole = 'patient';
      } else if (appNotif.type === 'daily-status') {
        if (this.currentRole === 'patient') return;
        targetRole = 'all';
      }

      const mapped: Notification = {
        id:      appNotif.id,
        type:    appNotif.type === 'message'      ? 'general'
               : appNotif.type === 'daily-status' ? 'test'
               : 'medication',
        title:   `${appNotif.title} — ${appNotif.message}`,
        time:    appNotif.time,
        iconBg:  appNotif.type === 'medication'   ? 'bg-blue-600'
               : appNotif.type === 'message'      ? 'bg-green-500'
               : appNotif.type === 'daily-status' ? 'bg-purple-600'
               : 'bg-slate-500',
        read_at:       null,
        isMissedLocal: false,
        targetRole
      };
      this.notifications = [mapped, ...this.notifications];
    });
  }

  ngOnDestroy(): void {
    this.missedSub?.unsubscribe();
    this.appNotifSub?.unsubscribe();
  }

  loadNotifications(): void {
    this.http.get<any>(`${API_BASE_URL}/notifications`, {
      headers: this.authHeaders
    })
    .pipe(finalize(() => this.isLoading = false))
    .subscribe({
      next: (res) => {
        const list = res.data?.items || res.data || res.notifications || (Array.isArray(res) ? res : []);

        const apiNotifs: Notification[] = list
          .filter((n: any) => {
            // ✅ شيل الـ message notifications من الأساس من الـ API
            const type  = (n.type || n.data?.type || '').toLowerCase();
            const title = (n.data?.message || n.data?.title || n.message || n.title || '').toLowerCase();
            const isMessage = type.includes('message') || type.includes('chat')
                           || title.includes('sent you a new message')
                           || title.includes('new message');
            return !isMessage;
          })
          .map((n: any) => ({
            id:         n.id,
            type:       this.resolveType(n.type || n.data?.type || ''),
            title:      n.data?.message || n.data?.title || n.data?.body ||
                        n.message || n.title || n.body || 'Notification',
            time:       n.created_at
                        ? new Date(n.created_at).toLocaleString('en-GB', {
                            hour: '2-digit', minute: '2-digit',
                            day: 'numeric',  month: 'short'
                          })
                        : '',
            iconBg:     this.resolveIconBg(n.type || n.data?.type || ''),
            read_at:    n.read_at,
            targetRole: 'all' as const
          }));

        const localMissed = this.notifications.filter(n => n.isMissedLocal);
        this.notifications = [...localMissed, ...apiNotifs];
      },
      error: (err) => {
        console.error('Notifications error:', err);
        if (err.status === 401) this.router.navigate(['/login']);
      }
    });
  }

  markAllAsRead(): void {
    this.http.post(`${API_BASE_URL}/notifications/read-all`, {}, {
      headers: this.authHeaders
    }).subscribe({
      next: () => {
        // ✅ امسح كل الـ messages نهائياً وعلّم الباقي كـ read
        this.notifications = this.notifications
          .filter(n => n.type !== 'general')  // ✅ شيل الـ messages كلها
          .map(n => ({ ...n, read_at: new Date().toISOString() }));
      },
      error: (err) => console.error(err)
    });
  }

  markAsRead(notification: Notification): void {
    // ✅ لو message → امسحها فوراً من القائمة وروح للشات
    if (notification.type === 'general') {
      this.notifications = this.notifications.filter(n => n.id !== notification.id);

      // ابعت للـ API إنها اتقرأت (بس في الـ background)
      if (!notification.isMissedLocal) {
        this.http.post(`${API_BASE_URL}/notifications/${notification.id}/read`, {}, {
          headers: this.authHeaders
        }).subscribe({ next: () => {}, error: () => {} });
      }

      this.navigateTo(notification);
      return;
    }

    // ✅ لو missed local → علّمها read بس متمسحهاش
    if (notification.isMissedLocal) {
      notification.read_at = new Date().toISOString();
      this.navigateTo(notification);
      return;
    }

    // ✅ باقي الـ notifications → علّمها read
    if (notification.read_at) {
      this.navigateTo(notification);
      return;
    }

    this.http.post(`${API_BASE_URL}/notifications/${notification.id}/read`, {}, {
      headers: this.authHeaders
    }).subscribe({
      next: () => {
        notification.read_at = new Date().toISOString();
        this.navigateTo(notification);
      },
      error: (err) => console.error(err)
    });
  }

  private navigateTo(notification: Notification): void {
    if (notification.type === 'general') {
      this.router.navigate(['/chat']);
      return;
    }
    if (notification.isMissedLocal || notification.type === 'medication') {
      this.router.navigate(['/add-new-medication']);
      return;
    }
    if (notification.type === 'test' || notification.type === 'doctor') {
      this.router.navigate(['/doctor-cards']);
      return;
    }
  }

  private resolveType(type: string): Notification['type'] {
    if (type.includes('medication') || type.includes('Medication')) return 'medication';
    if (type.includes('test') || type.includes('scan') || type.includes('report')) return 'test';
    if (type.includes('doctor') || type.includes('prescription')) return 'doctor';
    return 'general';
  }

  private resolveIconBg(type: string): string {
    if (type.includes('medication') || type.includes('Medication')) return 'bg-blue-600';
    if (type.includes('test') || type.includes('scan') || type.includes('report')) return 'bg-purple-600';
    if (type.includes('doctor') || type.includes('prescription')) return 'bg-blue-500';
    return 'bg-slate-500';
  }

  get unreadCount(): number {
    return this.notifications.filter(n => !n.read_at).length;
  }
}