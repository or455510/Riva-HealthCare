import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { finalize } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthService } from '../../../../service/auth.service';
import { API_BASE_URL } from '../../../../constants';
import { MissedMedicationService } from '../../../../service/missed-medication.service';
import { NotificationService } from '../../../../service/notification.service';

@Component({
  selector: 'app-dashboard-p',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule, HttpClientModule],
  templateUrl: './dashboard-p.component.html',
  styleUrls: ['./dashboard-p.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DashboardPComponent implements OnInit, OnDestroy {

  painLevel: number = 5;
  selectedMood: number | null = 5;
  notes: string = '';
  sleepQuality: string = 'fair';

  uploadedFile: File | null = null;
  fileName: string = '';
  filePreview: string | null = null;

  isLoading: boolean = false;
  isLoadingMed: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  currentpatient = { name: '', status: 'Active', avatar: '' };
  todayMedication: any = null;
  isMissed: boolean = false;
  missedReported: boolean = false;

  private missedCheckInterval: any;

  moods = [
    { id: 1,  emoji: '🤩', level: 1,  value: 'great'    },
    { id: 3,  emoji: '😃', level: 3,  value: 'good'     },
    { id: 5,  emoji: '😊', level: 5,  value: 'okay'     },
    { id: 7,  emoji: '😔', level: 7,  value: 'low'      },
    { id: 10, emoji: '😠', level: 10, value: 'terrible' },
  ];

  week = [
    { day: 'S',  taken: false },
    { day: 'M',  taken: true  },
    { day: 'T',  taken: false },
    { day: 'W',  taken: false },
    { day: 'Th', taken: false },
    { day: 'F',  taken: false },
    { day: 'Sa', taken: false },
  ];

  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private router: Router,
    private missedMedService: MissedMedicationService,
    private notifService: NotificationService   // ✅ أضف ده

  ) {}

  private get authHeaders() {
    return { Authorization: `Bearer ${this.authService.getToken()}` };
  }

  ngOnInit(): void {
    this.loadPatientProfile();
    this.loadTodayMedication();

    this.missedCheckInterval = setInterval(() => {
      this.checkIfMissed();
    }, 60000);
  }

  ngOnDestroy(): void {
    if (this.missedCheckInterval) clearInterval(this.missedCheckInterval);
  }

  loadPatientProfile(): void {
    this.http.get<any>(`${API_BASE_URL}/profile`, {
      headers: this.authHeaders
    }).subscribe({
      next: (res) => {
        const user = res.user || res.data || res;
        this.currentpatient.name   = `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'Patient';
this.currentpatient.avatar = user.profile_image_url
  || (user.profile_image ? `http://127.0.0.1:8000/storage/${user.profile_image}` : null)
  || `https://ui-avatars.com/api/?name=${encodeURIComponent(this.currentpatient.name)}&background=E0F2FE&color=0EA5E9`;
      },
      error: () => {}
    });
  }

loadTodayMedication(): void {
  this.isLoadingMed = true;
  this.http.get<any>(`${API_BASE_URL}/medications`, {
    headers: this.authHeaders
  }).subscribe({
    next: (res) => {
      const list: any[] = res.data || res || [];
      this.todayMedication = list.length > 0 ? list[0] : null;
      this.isLoadingMed = false;
      this.checkIfMissed();
      this.scheduleMedicationReminder(); // ✅ أضف ده
    },
    error: () => { this.isLoadingMed = false; }
  });
}

// ✅ ميثود جديدة — تذكير قبل 30 دقيقة
scheduleMedicationReminder(): void {
  if (!this.todayMedication?.schedule_time) return;

  const now = new Date();
  const [hours, minutes] = this.todayMedication.schedule_time.split(':').map(Number);
  const scheduleMs = new Date().setHours(hours, minutes, 0, 0);
  const reminderMs = scheduleMs - 30 * 60 * 1000; // 30 دقيقة قبل
  const delay = reminderMs - now.getTime();

  if (delay > 0) {
    setTimeout(() => {
      const name = this.todayMedication?.drug_name
                || this.todayMedication?.medication_name
                || 'your medication';
      this.notifService.push(
        'medication',
        '💊 Medication Reminder',
        `Time to take ${name} in 30 minutes (due at ${this.todayMedication.schedule_time})`
      );
    }, delay);
  }
}

  checkIfMissed(): void {
    if (!this.todayMedication?.schedule_time || this.missedReported) return;

    const now = new Date();
    const [hours, minutes] = this.todayMedication.schedule_time.split(':').map(Number);
    const scheduleMinutes = hours * 60 + minutes;
    const nowMinutes = now.getHours() * 60 + now.getMinutes();

    const notTaken = !this.todayMedication.taken_today
                  && !this.todayMedication.is_taken
                  && this.todayMedication.status !== 'taken';

    if (nowMinutes > scheduleMinutes + 2 && notTaken) {
      this.isMissed = true;
      this.reportMissed();

      this.missedMedService.addMissed({
        id: this.todayMedication.id,
        medicationName: this.todayMedication.name
                     || this.todayMedication.medication_name
                     || 'Medication',
        scheduleTime: this.todayMedication.schedule_time,
        reportedAt: new Date().toISOString()
      });
    }
  }

  reportMissed(): void {
    if (!this.todayMedication?.id || this.missedReported) return;
    this.missedReported = true;

    this.http.post(
      `${API_BASE_URL}/medications/${this.todayMedication.id}/missed`,
      {},
      { headers: this.authHeaders }
    ).subscribe({
      next: () => console.log('[Dashboard] Missed medication reported'),
      error: () => { this.missedReported = false; }
    });
  }

  get adherence(): number {
    const takenDays = this.week.filter(d => d.taken).length;
    return Math.round((takenDays / this.week.length) * 100);
  }

  get patientInitials(): string {
    if (!this.currentpatient?.name) return '';
    return this.currentpatient.name
      .split(' ').map((w: string) => w[0]).join('').toUpperCase().slice(0, 2);
  }

  private getMoodValue(): string {
    return this.moods.find(m => m.id === this.selectedMood)?.value ?? 'okay';
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    this.uploadedFile = file;
    this.fileName = file.name;
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e: any) => (this.filePreview = e.target.result);
      reader.readAsDataURL(file);
    } else {
      this.filePreview = null;
    }
  }

  removeFile() {
    this.uploadedFile = null;
    this.fileName = '';
    this.filePreview = null;
  }

  selectMood(mood: any) {
    this.selectedMood = mood.id;
    this.painLevel = mood.level;
  }

  updateMoodFromSlider() {
    const closest = this.moods.reduce((prev, curr) =>
      Math.abs(curr.level - this.painLevel) < Math.abs(prev.level - this.painLevel) ? curr : prev
    );
    this.selectedMood = closest.id;
  }

  onTakeMedication() {
    if (!this.todayMedication) return;
    this.http.post(`${API_BASE_URL}/medications/${this.todayMedication.id}/take`, {},
      { headers: this.authHeaders }
    ).subscribe({
      next: () => {
        this.isMissed = false;
        this.missedReported = true;
        const nextDay = this.week.find(d => !d.taken);
        if (nextDay) nextDay.taken = true;
      },
      error: () => {}
    });
  }

  remindLater() {
    if (!this.todayMedication) return;
    this.http.post(`${API_BASE_URL}/medications/${this.todayMedication.id}/snooze`, {},
      { headers: this.authHeaders }
    ).subscribe({ next: () => {}, error: () => {} });
    alert('Reminder snoozed for 30 minutes.');
  }

  toggleDay(day: any) { day.taken = !day.taken; }

  getMoodEmoji(): string {
    return this.moods.find(m => m.id === this.selectedMood)?.emoji ?? '';
  }

  // ✅ FIXED: submitCheckIn now sends FormData to support file uploads
  // and uses 1/0 for medication_taken to avoid boolean validation error
  submitCheckIn() {
    this.errorMessage  = '';
    this.successMessage = '';

    const medTaken = this.week.find(d => d.day === 'M')?.taken ?? false;

    const formData = new FormData();
    formData.append('mood',             this.getMoodValue());
    formData.append('pain_level',       String(this.painLevel));
    formData.append('sleep_quality',    this.sleepQuality);
    formData.append('symptoms',         this.notes);
    formData.append('notes',            this.notes);
    // ✅ FIX 1: send 1/0 instead of "true"/"false" — Laravel boolean validation accepts 1/0
    formData.append('medication_taken', medTaken ? '1' : '0');

    // ✅ FIX 2: attach the actual file so it reaches the doctor
    if (this.uploadedFile) {
      formData.append('attachment', this.uploadedFile, this.uploadedFile.name);
    }

    this.isLoading = true;

    // ✅ FIX 3: do NOT set Content-Type manually — browser sets it with the correct boundary
    this.http.post(`${API_BASE_URL}/daily-status`, formData, {
      headers: { Authorization: `Bearer ${this.authService.getToken()}` }
    })
    .pipe(finalize(() => (this.isLoading = false)))
    .subscribe({
     // في الـ next بتاع submitCheckIn
next: () => {
  this.successMessage = 'Daily report submitted successfully! ✅';

  // ✅ أضف ده
  this.notifService.push(
    'daily-status',
    '📋 Daily Status Sent',
    `${this.currentpatient.name}'s daily health report has been submitted successfully.`
  );

  this.resetForm();
},
      error: (err) => {
        if (err.status === 422) {
          const errors = err.error?.errors;
          this.errorMessage = errors
            ? Object.values(errors).flat().join(' | ')
            : 'Validation error.';
        } else {
          this.errorMessage = err.error?.message || 'Something went wrong.';
        }
      }
    });
  }

  resetForm() {
    this.notes = '';
    this.sleepQuality = 'fair';
    this.painLevel = 5;
    this.selectedMood = 5;
    this.removeFile();
  }
}