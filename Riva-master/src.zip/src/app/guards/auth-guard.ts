import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, UrlTree } from '@angular/router';
import { AuthService } from "../service/auth.service";

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(private auth: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean | UrlTree {
    if (!this.auth.isAuthenticated()) {
      return this.router.createUrlTree(['/signin']);
    }

    const allowedRoles = route.data?.['roles'] as string[] | undefined;
    const role = this.auth.getUserRole();

    if (allowedRoles?.length && !allowedRoles.includes(role)) {
      return this.router.createUrlTree([this.auth.dashboardRouteForRole(role)]);
    }

    return true;
  }
}
